-- rxi.json has been removed and replaced by Defold native json.encode and json.decode

return _G.json