The input modules have been moved to [their own repository](https://github.com/britzl/defold-input).
