The platformer.lua module has been moved to [it's own repository](https://github.com/britzl/platypus).
