components {
  id: "script"
  component: "/orthographic/camera.script"
}
embedded_components {
  id: "camera"
  type: "camera"
  data: "aspect_ratio: 0.0\n"
  "fov: 0.0\n"
  "near_z: -1.0\n"
  "far_z: 1.0\n"
  "orthographic_projection: 1\n"
  ""
}
